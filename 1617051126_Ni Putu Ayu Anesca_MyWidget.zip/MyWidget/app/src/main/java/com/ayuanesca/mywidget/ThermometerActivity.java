package com.ayuanesca.mywidget;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Kofi Gyan on 12/16/2015.
 */

public class ThermometerActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thermometer);

    }


}
